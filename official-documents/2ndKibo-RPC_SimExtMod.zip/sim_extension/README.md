# Kibo-RPC SimExtMod Ver.1.0.4

This directory contains files to extend Astrobee simulator for 2nd Kibo-RPC.

## How to use
Please run bellow code in this directory.

``` sh
chmod +x setup.sh
./setup.sh
```

Then, launch Astrobee Simulator.

``` sh
roslaunch astrobee sim.launch dds:=false robot:=sim_pub rviz:=true world:=iss
```

Please set KOZ pattern(pattern 1 ~ 8).
``` sh
./set_koz.sh <pattern_no>
```

If the camera images are incorrect, it can be because the simulator cannot keep up.
Then the speed of simulation can be decreased, for example, try bellow.

``` sh
roslaunch astrobee sim.launch dds:=false robot:=sim_pub rviz:=true world:=iss speed:=0.5
```

If Astrobee is not stable, run bellow code at another terminal and restart rviz.

``` sh
run executive teleop_tool -reset_bias
```

## Reference

1. 2st Kibo Robot Programming Challenge Programming manual chapter 4.6.8

## Change log

- Ver.1.0.4, April 19th, 2021
  - Fixed bug: getRobotKinematics and getTrustedRobotKinematics always returns position(0, 0, 0) and orientation(0, 0, 0, 0).
  - Face-forward mode are automatically set "OFF" when the simulator is launched.
  - Remove the old version and execute the following command with this new module to update from the old one.
``` sh
./update_to_v1.0.4.sh
```

- Ver.1.0.3, April 14th, 2021
  - Updated qr_7.png for fixing wrong position of P-A'.
  - Changed the value of x_max in KIZ_2.
  - Remove the old version and execute the following command with this new module to update from the old one.
``` sh
./set_koz.sh <pattern_no>
```

- Ver.1.0.2, April 9th, 2021
  - Updated qr_n.png for fixing wrong values of y-axis.
    Remove the old version and execute the following command with this new module to update from the old one.
``` sh
./set_koz.sh <pattern_no>
```

- Ver.1.0.1, April 8th, 2021
  - Updated zones_n.bin for fixing wrong values of KIZ and KOZ.
    Remove the old version and execute the following command with this new module to update from the old one.
``` sh
./set_koz.sh <pattern_no>
```

- Ver.1.0.0, April 1st, 2021
  - Initial Release