#!/bin/bash
SCRIPT_DIR=$(cd $(dirname $0); pwd)
PATCH_SRC_PATH=./files/patch/src/astrobee

# check values
if [ -z "$SOURCE_PATH" ]; then
    echo "[ERROR] Plsease set SOURCE_PATH"
    exit 1
fi

if [ -z "$BUILD_PATH" ]; then
    echo "[ERROR] Plsease set BUILD_PATH"
    exit 1
fi

# install package
echo "Please input sudo password for install rviz plugin."
sudo apt install -y ros-kinetic-jsk-rviz-plugins

# Copy new files
cp -r ./files/astrobee/* ${SOURCE_PATH}

# apply patchs.
while read patch_file; do
    patch ${SOURCE_PATH}/${patch_file} ${PATCH_SRC_PATH}/${patch_file}.patch
done < ./files/patch/filelist.txt

# Build simulator
source $BUILD_PATH/devel/setup.bash
cd $BUILD_PATH
make -j4
