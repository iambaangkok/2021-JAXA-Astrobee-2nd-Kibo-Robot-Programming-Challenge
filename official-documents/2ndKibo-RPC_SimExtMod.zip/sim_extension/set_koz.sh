#!/bin/bash
pattern_no=$1

# check values
if [ -z "${SOURCE_PATH}" ]; then
    echo "[ERROR] Please set SOURCE_PATH"
    exit 1
fi

if [ -z "${pattern_no}" ]; then
    echo "[ERROR] Please chose pattern_no."
    exit 1
fi


if [ 1 -le ${pattern_no} ] && [ ${pattern_no} -le 8 ]; then

    INPUT_PATH=./files/objects
    OUTPUT_PATH=${SOURCE_PATH}

    echo "You chose pattern_no ${pattern_no}."
    cp ${INPUT_PATH}/model_${pattern_no}.urdf ${OUTPUT_PATH}/description/media/astrobee_iss/urdf/model.urdf
    cp ${INPUT_PATH}/qr_${pattern_no}.png ${OUTPUT_PATH}/description/media/astrobee_iss/media/materials/textures/qr.png
    cp ${INPUT_PATH}/zones_${pattern_no}.bin ${OUTPUT_PATH}/astrobee/resources/zones/iss.bin

    echo "copy objects done!"
    exit 0
else
    echo "[ERROR] Please select pattern_no between 1 and 8."
    exit 1
fi
