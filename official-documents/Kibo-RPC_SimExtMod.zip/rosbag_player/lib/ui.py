#!/usr/bin/env python2

from PyQt5.QtCore import *
from PyQt5.QtWidgets import *

class ConfigWindowUI(QWidget):
    def initUI(self):
        # Group Speed
        self.groupSpeed = QGroupBox('Speed')

        self.speedEdit = QLineEdit()
        self.speedEdit.setAlignment(Qt.AlignCenter)
        self.speedEdit.setText('1.0')
        self.speedEdit.setReadOnly(True)

        self.speedSlider = QSlider(Qt.Horizontal)
        self.speedSlider.setMinimum(1)
        self.speedSlider.setMaximum(30)
        self.speedSlider.setValue(10)
        self.speedSlider.setTickInterval(5)

        gridSpeed = QGridLayout()
        gridSpeed.setSpacing(10)
        gridSpeed.addWidget(self.speedEdit, 1, 0)
        gridSpeed.addWidget(self.speedSlider, 2, 0)

        self.groupSpeed.setLayout(gridSpeed)
        # Group Range
        self.groupRange = QGroupBox('Range')

        self.timeLabelStart = QLabel('Start')
        self.timeLabelEnd = QLabel('End')
        self.timeCbStart = QComboBox()
        self.timeCbEnd = QComboBox()

        self.chapterNameList = []
        for chapterList in self.chapterLists:
            self.chapterNameList.append(chapterList.name)

        self.timeCbStart.addItems(self.chapterNameList[0:-1])
        self.timeCbEnd.addItems(self.chapterNameList[1:])
        self.timeCbEnd.setCurrentIndex(self.timeCbEnd.count()-1)

        gridRange = QGridLayout()
        gridRange.addWidget(self.timeLabelStart, 1, 0)
        gridRange.addWidget(self.timeCbStart, 1, 1)
        gridRange.addWidget(self.timeLabelEnd, 2, 0)
        gridRange.addWidget(self.timeCbEnd, 2, 1)

        self.groupRange.setLayout(gridRange)

        self.playButton = QPushButton("Play", self)
        self.playButton.setToolTip('Start playing rosbag')

        grid = QGridLayout()
        grid.addWidget(self.groupSpeed, 1, 0)
        grid.addWidget(self.groupRange, 2, 0)
        grid.addWidget(self.playButton, 3, 0)

        self.setLayout(grid)
        self.setWindowTitle('PlayConfig')

class PlayWindowUI(QWidget):
    def initUI(self):
        self.pauResButton = QPushButton("Pause", self)
        self.backButton = QPushButton("Stop", self)

        grid = QGridLayout()
        grid.setSpacing(10)

        grid.addWidget(self.pauResButton, 1, 0)
        grid.addWidget(self.backButton, 1, 1)

        self.pauResButton.setToolTip('Pause playing rosbag')
        self.backButton.setToolTip('stop and back to config window')

        self.setLayout(grid)
        self.setWindowTitle('PlayControl')

