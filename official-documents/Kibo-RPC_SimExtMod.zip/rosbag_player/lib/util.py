#!/usr/bin/env python2
import json
import datetime

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPalette, QColor

def getDarkPalette():
    darkPalette = QPalette()

    darkPalette.setColor(QPalette.Window, QColor(53, 53, 53))
    darkPalette.setColor(QPalette.WindowText, Qt.white)
    darkPalette.setColor(QPalette.Base, QColor(25, 25, 25))
    darkPalette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
    darkPalette.setColor(QPalette.ToolTipBase, Qt.white)
    darkPalette.setColor(QPalette.ToolTipText, Qt.white)
    darkPalette.setColor(QPalette.Text, Qt.white)
    darkPalette.setColor(QPalette.Button, QColor(53, 53, 53))
    darkPalette.setColor(QPalette.ButtonText, Qt.white)
    darkPalette.setColor(QPalette.BrightText, Qt.red)
    darkPalette.setColor(QPalette.Link, QColor(42, 130, 218))
    darkPalette.setColor(QPalette.Highlight, QColor(42, 130, 218))
    darkPalette.setColor(QPalette.HighlightedText, Qt.black)

    return darkPalette

def changeView(view1, view2):
    position = view1.pos()
    view2.move(position.x(), position.y())
    view2.show()
    view1.hide()

class Chapter():
    def __init__(self, name, sec):
        self.name = name
        self.sec = sec

def getChapterListsFromJson(jsonPath):
    def timeToChapter(chapterName, timedelta):
        return Chapter(chapterName, int(timedelta.total_seconds()))

    chapterLists = []

    with open(jsonPath) as f:
        resultJson = json.load(f)
        # Start
        time = resultJson.get('Mission Time', {}).get('start')
        if time is not None:
            time = datetime.datetime.strptime(time, '%Y%m%d %H%M%S%f')
            start = time
            chapterLists.append(timeToChapter('Start Position', time-start))

        # QR
        qrLabel = ['P1-1', 'P1-2', 'P1-3', 'P2-1', 'P2-2', 'P2-3']
        for i in range(6):
            time = resultJson.get('QR', {}).get(str(i), {}).get('timestamp')
            if time is not None:
                time = datetime.datetime.strptime(time, '%Y%m%d %H%M%S%f')
                chapterLists.append(timeToChapter(qrLabel[i], time-start))

        # AR
        time = resultJson.get('AR', {}).get('timestamp')
        if time is not None:
            time = datetime.datetime.strptime(time, '%Y%m%d %H%M%S%f')
            chapterLists.append(timeToChapter('P3', time-start))

        # Approach
        time = resultJson.get('Approach', {}).get(str(0), {}).get('timestamp')
        if time is not None:
            time = datetime.datetime.strptime(time, '%Y%m%d %H%M%S%f')
            chapterLists.append(timeToChapter('TargetPosition', time-start))

        # Finish
        time = resultJson.get('Mission Time', {}).get('finish')
        if time is not None:
            time = datetime.datetime.strptime(time, '%Y%m%d %H%M%S%f')
            chapterLists.append(timeToChapter('End of Simulation', time-start))
        else:
            chapterLists.append(Chapter('End of Simulation', None))

    return chapterLists

