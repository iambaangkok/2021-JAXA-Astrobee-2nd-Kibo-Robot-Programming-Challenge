#!/usr/bin/env python2

import sys
import time
import signal
import yaml

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

from lib.cmd_wrapper import RvizWrapper, RosbagWrapper
from lib.ui import ConfigWindowUI, PlayWindowUI
from lib.util import getDarkPalette, changeView, Chapter, getChapterListsFromJson

CONFIG_PATH = 'conf/config.yaml'

class ConfigWindow(ConfigWindowUI):
    def __init__(self, chapterLists, terminator, parent=None):
        super(ConfigWindow, self).__init__(parent)

        self.chapterLists = chapterLists

        self.initUI()
        if terminator:
            self.setWindowFlags(Qt.WindowStaysOnTopHint)
        else:
            self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
        self.speedSlider.valueChanged.connect(self.sliderCallback)
        self.timeCbStart.activated[str].connect(self.cbStartCallback)
        self.timeCbEnd.activated[str].connect(self.cbEndCallback)
        self.playButton.clicked.connect(self.playButtonCallback)

    def sliderCallback(self):
        value = self.speedSlider.value()
        rosbagWrapper.speed = str(value/10.0)
        self.speedEdit.setText(str(value/10.0))

    def cbStartCallback(self, text):
        count = 0
        for chapterList in self.chapterLists:
            if chapterList.name == text:
                rosbagWrapper.startSec = chapterList.sec

                selectedText = self.timeCbEnd.currentText()
                self.timeCbEnd.clear()
                self.timeCbEnd.addItems(self.chapterNameList[count+1:])

                selectedIndex = self.timeCbEnd.findText(selectedText)
                NOT_FOUND = -1
                if selectedIndex == NOT_FOUND:
                    rosbagWrapper.endSec = None
                    self.timeCbEnd.setCurrentIndex(self.timeCbEnd.count()-1)
                else:
                    self.timeCbEnd.setCurrentIndex(selectedIndex)

                break
            else:
                count +=1

    def cbEndCallback(self, text):
        for chapterList in self.chapterLists:
            if chapterList.name == text:
                if chapterList.sec is None:
                    rosbagWrapper.endSec = None
                    break
                else:
                    rosbagWrapper.endSec = chapterList.sec
                    break

    def playButtonCallback(self):
        while rvizWrapper.running:
            rvizWrapper.stop()
            time.sleep(5)
        rvizWrapper.start()
        rosbagWrapper.signal.connect(self.returnView)
        rosbagWrapper.start()
        changeView(self, playWindow)

    def returnView(self):
        changeView(playWindow, self)
        playWindow.pauResButton.setText('Pause')

    def closeEvent(self, event):
        rvizWrapper.stop()
        rosbagWrapper.stop()

class PlayWindow(PlayWindowUI):
    def __init__(self, terminator, parent=None):
        super(PlayWindow, self).__init__(parent)
        self.initUI()
        if terminator:
            self.setWindowFlags(Qt.WindowStaysOnTopHint)
        else:
            self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
        self.pauResButton.clicked.connect(self.pauResButtonCallback)
        self.backButton.clicked.connect(self.backButtonCallback)

    def pauResButtonCallback(self):
        if self.pauResButton.text() == 'Pause':
            rosbagWrapper.sendKey(' \n')
            self.pauResButton.setText('Resume')
            self.pauResButton.setToolTip('Resume playing rosbag')

        elif self.pauResButton.text() == 'Resume':
            rosbagWrapper.sendKey(' \n')
            self.pauResButton.setText('Pause')
            self.pauResButton.setToolTip('Pause playing rosbag')

    def backButtonCallback(self):
        rosbagWrapper.stop()
        changeView(self, configWindow)
        self.pauResButton.setText('Pause')

    def closeEvent(self, event):
        rvizWrapper.stop()
        rosbagWrapper.stop()

if __name__ == '__main__':
    # load config
    with open(CONFIG_PATH, 'r') as yml:
        config = yaml.load(yml)
    rvizCmd = config['cmd']['rviz']
    rosbagCmd = config['cmd']['rosbag']
    resultPath = config['path']['result']
    bagfilePath = config['path']['bagfile']
    terminator = config['terminator']

    # Initialize App
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setPalette(getDarkPalette())
    app.setStyleSheet("QToolTip { color: #ffffff; background-color: #2a82da; border: 1px solid white; }")

    chapterLists = getChapterListsFromJson(resultPath)
    rvizWrapper = RvizWrapper(rvizCmd)
    rosbagWrapper = RosbagWrapper(rosbagCmd, bagfilePath)
    configWindow = ConfigWindow(chapterLists, terminator)
    playWindow = PlayWindow(terminator)
    configWindow.show()

    sys.exit(app.exec_())
