#!/bin/bash

# CONSTANT VALUES
SCRIPT_DIR=$(cd $(dirname $0); pwd)
DEL_FILES=(".gitignore")
#ADD_FILES=("")

INPUT_PATH=${SCRIPT_DIR}
OUTPUT_PATH=$1
FILE_PATH=

DIR_NAME=./rosbag_player

# clean
if [ -d ${OUTPUT_PATH%/}/${DIR_NAME} ]; then
    rm -r ${OUTPUT_PATH%/}/${DIR_NAME}
fi

# copy files
cp -r ${INPUT_PATH} ${OUTPUT_PATH%/}/${DIR_NAME}

# delete unusual files
for del_file in "${DEL_FILES[@]}"
    do
        rm -r ${OUTPUT_PATH%/}/${DIR_NAME%/}/${del_file}
    done

# add new files
# for add_file in "${ADD_FILES[@]}"
#     do
#         cp ${FILE_PATH%/}/${add_file%/} ${OUTPUT_PATH%/}/${DIR_NAME}
#     done